//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int i = 1;
//	int tongtich = 1;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if(n<=1)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=1);
//	while (i<=n)
//	{
//		tongtich *= i;
//		i += 2;
//	}
//	cout << "Tong tich cac so le tu 1 den " << n << " la " << tongtich << endl;
//  system("pause");
//  return 0;
//}