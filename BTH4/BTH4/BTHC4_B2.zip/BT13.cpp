//#include<iostream>
//using namespace std;
//int main()
//{
//	int n, max=INT_MIN, min=INT_MAX;
//	int tong = 0;
//	cout << "Nhap vao cac so nguyen: ";
//	while (cin>>n)
//	{
//		if (n > max)
//			max = n;
//		if (n < min)
//			min = n;
//		tong += n;
//	}
//	cout << "So lon nhat " << max << endl;
//	cout << "So nho nhat " << min << endl;
//	cout << "Tong cac so vua nhap: " << tong << endl;
//	return 0;
//}