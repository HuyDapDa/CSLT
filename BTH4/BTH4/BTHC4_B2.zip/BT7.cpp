//#include<iostream>
//#include<cmath>
//#include<iomanip>
//using namespace std;
//int main()
//{
//	int a, b;
//	cout << "nhap 2 so nguyen: ";
//	cin >> a >> b;
//	int chon;
//	do
//	{
//		cout << "1.phep cong";
//		cout << "\n2.phep tru";
//		cout << "\n3.phep nhan";
//		cout << "\n4.phep chia";
//		cout << "\n5.thoat" << endl;;
//		cin >> chon;
//		switch (chon)
//		{
//		case 1:
//			cout<< "a + b = " << a + b << endl;
//			break;
//		case 2 :
//			cout<< "a - b = " << a - b << endl;
//			break;
//		case 3:
//			cout <<"a * b = " << a * b << endl;
//			break;
//		case 4:
//			if (b != 0)
//				cout << "a / b = " << setprecision(2) << double(a) / b <<  endl;
//			else
//				cout << "loi chia 0" << endl;
//			break;
//		default:
//			break;
//		}
//	} while (chon!=5);
//	
//	return 0;
//}