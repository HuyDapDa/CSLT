//#include<iostream>
//using namespace std;
//int main()
//{
//	int i = 1;
//	int n;
//	int tong = 0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//	} while (n<0);
//	while (i <= n)
//	{
//		tong += i;
//		i++;
//	}
//	cout << "Tong tu 1 den " << n << " la " << tong << endl;
//	return 0;
//}