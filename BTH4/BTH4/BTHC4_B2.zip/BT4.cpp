//#include<iostream>
//using namespace std;
//int main() 
//{
//	int n,chs,tam;
//	int dem = 0;
//	int tongch = 0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 0)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=0);
//	tam = n;
//	while (tam > 0)
//	{
//		chs = tam % 10;
//		tongch += chs;
//		dem++;
//		tam = tam / 10;
//	}
//	cout << n << " co " << dem << " chu so va tong cac chu so la: " << tongch << endl;
//}