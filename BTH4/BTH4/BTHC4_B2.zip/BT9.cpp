//#include <iostream>
//using namespace std;
//int main()
//{
//	int n1, n2,i;
//	int dem = 0;
//	do
//	{
//		cout << "Nhap 2 so nguyen: ";
//		cin >> n1 >> n2;
//		if (n1 >= n2 || n1 <= 0 || n2 <= 0)
//			cout << "Nhap sai, nhap lai!!!\n";
//	} while (n1 >= n2 || n1 <= 0 || n2 <= 0);
//	i = n1;
//	while (i <= n2)
//	{
//		if (10 % i == 0)
//			dem++;
//		i++;
//	}
//	cout << "So uoc cua 10 trong pham vi tu " << n1 << " den " << n2 << " la: " << dem << endl;
//	return 0;
//}
