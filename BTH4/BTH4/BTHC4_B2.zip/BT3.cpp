//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int i = 1;
//	int tongle = 0;
//	int tongchan = 0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 1)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=1);
//	while (i <= n)
//	{
//		if (i % 2 == 0)
//			tongchan += i;
//		else
//			tongle += i;
//		i++;
//	}
//	cout << "Tong le tu 1 den " << n << " la " << tongle << endl;
//	cout << "Tong chan tu 1 den " << n << " la " << tongchan << endl;
//	system("pause");
//	return 0;
//}