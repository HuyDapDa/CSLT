//#include<iostream>
//#include<cmath>
//using namespace std;
//int main()
//{
//	int Bin, Dec = 0;
//	int i = 0;
//}