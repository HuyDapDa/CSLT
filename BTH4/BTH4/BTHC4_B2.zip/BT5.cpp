//#include<iostream>
//using namespace std;
//int main()
//{
//	int n,tmp;
//	int dao=0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 0)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=0);
//	tmp = n;
//	while (tmp>0)
//	{
//
//		dao = dao * 10 + tmp % 10;
//		tmp = tmp / 10;
//	}
//	cout << "So dao nguoc cua " << n << " la " << dao << endl;
//	return 0;
//
//}