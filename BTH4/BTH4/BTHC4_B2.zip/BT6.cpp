#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	bool lasonguyento = true;
	cout << "Nhap so nguyen: ";
	cin >> n;
	if (n >= 2)
	{
		int i = 2;
		while (i <= sqrt((double)n) && lasonguyento)
		{
			if (n % i == 0)
				lasonguyento = false;
			i++;
		}
	}
	else
	{
		lasonguyento = false;
	}
	if (lasonguyento)
		cout << n << " la so nguyen to" << endl;
	else
		cout << n << " khong phai la so nguyen to" << endl;
	system("pause");
	return 0;
}