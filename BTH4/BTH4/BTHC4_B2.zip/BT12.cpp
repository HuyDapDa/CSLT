//#include<iostream>
//using namespace std;
//int main()
//{
//	int n,chs;
//	int i = 0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 0)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=0);
//	while (n>0)
//	{
//		chs = n % 10;
//		i = i * 10 + chs;
//		n = n / 10;
//	}
//	cout << "Ket qua: ";
//	while (i > 0)
//	{
//		chs = i % 10;
//		cout << chs << " ";
//		i = i / 10;
//	}
//	cout << endl;
//	return 0;
//}