//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int i = 2;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 0)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=0);
//	cout << "So " << n << " co cac thua so nguyen to: ";
//	while (n > 1)
//	{
//		if (n % i == 0)
//		{
//			cout << i;
//			n = n / i;
//			if (n > 1)
//				cout << ", ";
//		}
//		else
//			i++;
//	}
//	cout << endl;
//	system("pause");
//	return 0;
//}