//#include <iostream>
//using namespace std;
//int main()
//{
//	int n,tam,chs;
//	int tongle = 0;
//	do
//	{
//		cout << "Nhap n: ";
//		cin >> n;
//		if (n <= 0)
//			cout <<"Nhap sai, nhap lai!!!\n";
//	} while (n<=0);
//	tam = n;
//	while (tam>0)
//	{
//		chs = tam % 10;
//		if (chs % 2 == 1)
//			tongle += chs;
//		tam = tam / 10;
//	}
//	cout << "Tong chu so le cua " << n << " la: " << tongle << endl;
//	system("pause");
//	return 0;
//}