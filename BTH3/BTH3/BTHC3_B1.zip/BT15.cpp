#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int a, b, c;
	cout << "Nhap 3 canh tam giac: ";
	cin >> a >> b >> c;
	if (a + b > c && a + c > b && b + c > a)
	{
		if (a == b && b == c)
			cout << "Tam giac deu";
		else if (a == b || b == c || a == c)
			cout << "Tam giac can";
		else if (a * a + b * b == c * c || b * b + c * c == a * a || c * c + a * a == b * b)
			cout << "Tam giac vuong";
		else if (a * a + b * b > c * c || b * b + c * c > a * a || c * c + a * a > b * b)
			cout << "Tam giac thuong";
		else
			cout << "Tam giac vuong can";
	}
	else
		cout << "Khong lop le";

	
	return 0;
}