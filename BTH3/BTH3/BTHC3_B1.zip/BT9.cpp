//#include<iostream>
//#include<cmath>
//#include<iomanip>
//using namespace std;
//int main()
//{
//	int a, b;
//	cout << "Nhap 2 so nguyen: ";
//	cin >> a >> b;
//	int chon;
//
//	do
//	{
//
//		cout << "1.Phep cong";
//		cout << "\n2.Phep tru";
//		cout << "\n3.Phep nhan";
//		cout << "\n4.Phep chia";
//		cout << "\n5.Thoat" << endl;;
//		cin >> chon;
//		switch (chon)
//		{
//		case 1:
//			cout<< "a + b = " << a + b << endl;
//			break;
//		case 2 :
//			cout<< "a - b = " << a - b << endl;
//			break;
//		case 3:
//			cout <<"a * b = " << a * b << endl;
//			break;
//		case 4:
//			if (b != 0)
//				cout << "a / b = " << setprecision(2) << double(a) / b <<  endl;
//			else
//				cout << "Loi chia 0" << endl;
//			break;
//		default:
//			break;
//		}
//	} while (chon!=5);
//	
//	
//}