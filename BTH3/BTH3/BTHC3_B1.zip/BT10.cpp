//#include<iostream>
//using namespace std; 
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	if (n % 2 == 1)
//		cout << "So le";
//	else
//		cout << "So chan";
//	cout << endl;
//	return 0;
//}