//#include<iostream>
//using namespace std;
//int main()
//{
//	int a, b, max;
//	cout << "Nhap 2 so nguyen: ";
//	cin >> a >> b;
//	if (a > b)
//		max = a;
//	else
//		max = b;
//	cout << "So lon nhat: " << max << endl;
//	system("pause");
//	return 0;
//}