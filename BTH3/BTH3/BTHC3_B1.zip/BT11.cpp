//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	if (n > 0)
//		cout << "So duong";
//	else if (n < 0)
//		cout << "So am";
//	else
//		cout << "Bang 0";
//	cout << endl;
//	return 0;
//}