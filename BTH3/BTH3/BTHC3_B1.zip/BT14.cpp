//#include<iostream>
//using namespace std;
//int main()
//{
//	int a, b, c;
//	cout << "Nhap 3 so nguyen: ";
//	cin >> a >> b >> c;
//	if (a > b)
//	{
//		int temp = a;
//		a = b;
//		b = temp;
//	}
//	if (a > c)
//	{
//		int temp = a;
//		a = c;
//		c = temp;
//	}
//	if (b > c)
//	{
//		int temp = b;
//		b = c;
//		c = temp;
//	}
//	cout << "Cac so sau khi sap xep tang dan " << a << " ," << b << " ," << c << endl;
//	return 0;
//}