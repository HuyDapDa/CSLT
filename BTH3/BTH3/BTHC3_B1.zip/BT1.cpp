//#include<iostream>
//using namespace std;
//int main()
//{
//	double d;
//	cout << "Nhap diem: ";
//	cin >> d;
//	if (d >= 5)
//	{
//		cout << "Dau";
//	}
//	else
//		cout << "Rot";
//	cout << endl;
//	system("pause");
//	return 0;
//}