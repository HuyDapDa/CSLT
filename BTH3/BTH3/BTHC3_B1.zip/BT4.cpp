//#include<iostream>
//using namespace std;
//int main()
//{
//	int a, b;
//	cout << "Nhap 2 so nguyen: ";
//	cin >> a >> b;
//	if (a > b)
//		cout << "So " << a <<" lon hon " << b;
//	else if(a < b)
//		cout << "So " << b << " lon hon " << a;
//	else 
//		cout << "So " << a << " bang so " << b;
//	cout << endl;
//	system("pause");
//	return 0;
//}