//#include<iostream>
//using namespace std;
//int main()
//{
//	double diem;
//	cout << "Nhap diem: ";
//	cin >> diem;
//	if (diem < 5)
//		cout << "Yeu";
//	else if (diem < 6)
//		cout << "Trung binh";
//	else if (diem < 7)
//		cout << "Trung binh kha";
//	else if (diem < 8)
//		cout << "Kha";
//	else if (diem < 9)
//		cout << "Gioi";
//	else
//		cout << "Xuat sac";
//	cout << endl;
//	system("pause");
//	return 0;
//}