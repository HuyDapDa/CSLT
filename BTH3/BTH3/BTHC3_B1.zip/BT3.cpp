//#include<iostream>
//using namespace std;
//int main()
//{
//	int a;
//	cout << "Nhap so nguyen: ";
//	cin >> a;
//	if (a < 0)
//		cout<<"Gia tri tuyet doi cua "<< a << " la: " << abs(a);
//	else
//		cout << "Gia tri tuyet doi cua " << a << " la: " << a;
//	cout << endl;
//	system("pause");
//	return 0;
//}