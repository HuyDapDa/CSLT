//#include<iostream>
//#include<cmath>
//using namespace std;
//int main()
//{
//	double a, b;
//	cout << "Nhap 2 so: ";
//	cin >> a >> b;
//	if (a == 0)
//	{
//		if (b == 0)
//			cout << "Phuong trinh vo so nghiem.";
//		else
//			cout << "Phuong trinh vo nghiem.";
//	}
//	else
//	{
//		cout << "Phuong trinh co nghiem duy nhat la " << -b / a ;
//	}
//	cout << endl;
//	return 0;
//}