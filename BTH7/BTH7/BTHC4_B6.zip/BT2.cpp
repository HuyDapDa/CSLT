//#include <iostream>
//using namespace std;
//int euclid(int n, int m)
//{
//	while (n!=0)
//	{
//		int r = m / n;
//		m = n;
//		n = r;
//	}
//	return m;
//}
//void rutgon(int& a, int& b)
//{
//	int ucln = euclid(a, b);
//	a /= ucln;
//	b /= ucln;
//}
//int main()
//{
//	int a, b;
//	cout << "Nhap tu so: ";
//	cin >> a;
//	cout << "Nhap mau so: ";
//	cin >> b;
//	rutgon(a, b);
//	cout << "Phan so rut gon la: " << a << "/" << b << endl;
//	return 0;
//}