//#include <iostream>
//using namespace std;
//void hoandoi(int& n, int& m)
//{
//	int tmp = n;
//	n = m;
//	m = tmp;
//}
//void sapxep(int& n, int& m)
//{
//	if (n > m)
//	{
//		int tmp = n;
//		n = m;
//		m = tmp;
//	}
//	
//}
//int main()
//{
//	int n, m;
//	cout << "Nhap n,m: ";
//	cin >> n >> m;
//	hoandoi(n, m);
//	cout << "So sau khi hoan doi: " << n << ", " << m << endl;
//	sapxep(n, m);
//	cout << "So sau khi sap xep: " << n << ", " << m<< endl;
//	return 0;
//}