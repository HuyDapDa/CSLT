//#include <iostream>
//using namespace std;
//void nam(int n)
//{
//	if (n % 400 == 0 || n % 4 == 0 && n % 100 != 0)
//		cout << "Nam nhuan" << endl;
//	else
//		cout << "Khong phai la nam thuan" << endl;
//}
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	nam(n);
//	system("pause");
//	return 0;
//}