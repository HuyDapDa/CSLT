//#include <iostream>
//using namespace std;
//
//void solonnhat1(int a, int b,int c)
//{
//	int solonnhat = a > b ? a : b;
//	int solonhat3chuso = solonnhat > c ? solonnhat : c;
//	cout<< "So lon nhat 2 chu so: " << solonnhat << endl;
//	cout<< "So lon nhat giua 3 chu so: " << solonhat3chuso << endl;
//
//}
//
//int main()
//{
//	int a, b, c,solonnhat;
//	cout << "Nhap a,b,c: ";
//	cin >> a >> b >> c;
//	solonnhat1(a, b,c);
//	return 0;
//}