//#include <iostream>
//using namespace std;
//
//void dao(int n)
//{
//	int dao = 0;
//	int tmp;
//	tmp = n;
//	while (tmp > 0)
//	{
//		dao = dao * 10 + tmp % 10;
//		tmp = tmp / 10;
//	}
//	cout << "So dao nguoc cua mot so nguyen duong " << n << " la " << dao << endl;
//
//}
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	dao(n);
//	return 0;
//}