//#include <iostream>
//using namespace std;
//void hinhvuong(int canh)
//{
//	for (int i = 1;i <= canh;i++) {
//		for (int j = 1; j <= canh;j++)
//			cout << " *";
//		cout << endl;
//	}
//		
//}
//int main()
//{	
//	int canh;
//	cout << "Nhap canh: ";
//	cin >> canh;
//	hinhvuong(canh);
//	return 0;
//}