//#include <iostream>
//using namespace std;
//
//void hinhchunhat(int dai, int rong)
//{
//	cout << "Dien tich hinh chu nhat: " << dai * rong<<endl;
//	cout << "Chu vi hinh chu nhat: " << (dai+rong)  * 2 << endl;
//
//}
//int main()
//{	
//	int dai, rong;
//	cout << "Nhap chieu dai, chieu rong: ";
//	cin >> dai >> rong;
//	hinhchunhat(dai, rong);
//	return 0;
//}