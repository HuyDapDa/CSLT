//#include <iostream>
//using namespace std;
//void hinhvuong(int canh)
//{
//	cout << "Dien tich hinh vuong: " << canh * canh << endl;
//	cout << "Chu vi hinh vuong: " << canh * 4<<endl;
//	for (int i = 1; i <= canh; i++)
//	{
//		for (int j = 1; j <= canh; j++)
//			if (i == 1 || i == canh || j == 1 || j == canh)
//			{
//				cout << "*";
//			}
//			else
//				cout << " ";
//		cout << endl;
//	}
//		
//		
//
//}
//int main()
//{
//	int canh;
//	cout << "Nhap canh: ";
//	cin >> canh;
//	hinhvuong(canh);
//	return 0;
//}