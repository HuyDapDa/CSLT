//#include <iostream>
//using namespace std;
//bool kiem_tra(int n)
//{
//	int tonguoc = 0;
//	for (int i = 1; i < n; i++)
//		if (n % i == 0)
//			tonguoc += i;
//	if (tonguoc == n)
//		return true;
//	else
//		return false;
//}
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//
//	if (kiem_tra(n))
//		cout << n << " la so hoan thien" << endl;
//	else
//		cout << n << " khong phai la so hoan thien" << endl;
//	return 0;
//}