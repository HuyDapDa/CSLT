//#include <iostream>
//using namespace std;
//void tong(int n)
//{
//	int dem = 0;
//	int chs, tam;
//	int tongCh = 0;
//	tam = n;
//	while (tam>0)
//	{
//		chs = tam % 10;
//		tongCh += chs;
//		dem++;
//		tam = tam / 10;
//	}
//	cout << "Tong chu so cua " << n << " la " << tongCh << endl;
//}
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	tong(n);
//	return 0;
//}