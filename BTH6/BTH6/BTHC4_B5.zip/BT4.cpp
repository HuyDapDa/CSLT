﻿//#include <iostream>
//using namespace std;
//
//void tong(int n)
//{
//	int tong = 0;
//	for (int i = 0; i <= n; i++)
//		tong += i;
//	cout << "Tong cac so tu 1 den " << n << " la " << tong<<endl;
//}
//void giaithua(int n)
//{
//	int tich = 1;
//	for (int i = 1 ; i <= n ; i++)
//		tich *= i;
//	cout << "Giai thua cua " << n << " la " <<tich << endl;
//}
//int main()
//{
//	int n;
//	cout << "Nhap n: ";
//	cin >> n;
//	tong(n);
//	giaithua(n);
//	return 0;
//}