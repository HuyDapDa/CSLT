//#include <iostream>
//#include <cmath>
//using namespace std;
//
//void mu(int a, double b)
//{
//	cout << a << " mu " << b << " = " << pow(a, b) << endl;
//
//}
//int main()
//{	
//	int a;
//	double b;
//	cout << "Nhap a, b: ";
//	cin >> a >> b;
//	mu(a, b);
//	return 0;
//}