//#include <iostream>
//using namespace std;
//int main()
//{
//	double canh;
//	cout << "Nhap canh hinh vuong: ";
//	cin >> canh;
//	cout << "Dien tich hinh vuong " << canh * canh << endl;
//	system("pause");
//	return 0;
//}