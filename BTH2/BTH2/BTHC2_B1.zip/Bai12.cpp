//#include<iostream>
//#include<string>
//using namespace std;
//int main()
//{
//	string s;
//	cout << "Nhap chuoi: ";
//	getline(cin, s);
//	cout << "Do dai cua chuoi: " << s.length() << endl;
//	system("pause");
//	return 0;
//
//}