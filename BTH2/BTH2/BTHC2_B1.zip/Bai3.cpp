//#include <iostream>
//#include <string>
//using namespace std;
//int main()
//{
//	string ten;
//	int ngaylam;
//	int tiencong;
//	cout << "Nhap ten: ";
//	getline(cin, ten);
//	cout << "So ngay lam viec: ";
//	cin >> ngaylam;
//	cout << "Tien cong: ";
//	cin >> tiencong;
//	cout << "Ten: " << ten << "\nTien luong nhan duoc: " << ngaylam * tiencong << endl;
//	system("pause");
//	return 0;
//}