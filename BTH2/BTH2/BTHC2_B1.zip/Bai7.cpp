//#include<iostream>
//#include<cmath>
//using namespace std;
//int main()
//{
//	double a, b, c, d,e;
//	cout << "Nhap vao toa do diem thu 1: ";
//	cin >> a >> b;
//	cout << "Nhap vao toa do diem thu 2: ";
//	cin >> c >> d;
//	e = sqrt((pow(b, 2) - 2 * a * b + pow(a, 2)) + (pow(d, 2) + 2 * d * c + pow(c, 2)));
//	cout << "Do dai khoang cach: " << e << endl;
//	system("pause");
//	return 0;
//}