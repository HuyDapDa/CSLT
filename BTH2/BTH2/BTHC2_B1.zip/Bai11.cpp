//#include <iostream>
//#include <cmath>
//using namespace std;
//double pi = 3.14;
//int main()
//{
//	double x;
//	cout << "Nhap x: ";
//	cin >> x;
//	double radian = x * pi / 180;
//	cout << "sin(" << x << ")= " << sin(radian) << endl;
//	cout << "cos(" << x << ")= " << cos(radian) << endl;
//	cout << "tan(" << x << ")= " << tan(radian) << endl;
//	system("pause");
//	return 0;
//
//}
