//#include <iostream>
//#include <cmath>
//using namespace std;
//int main()
//{
//	double a, b, c, p;
//	cout << "Nhap 3 canh tam giac: ";
//	cin >> a >> b >> c;
//	p = (a + b + c) / 2;
//	cout << "Dien tich tam giac: " << sqrt(p * (p - a) * (p - b) * (p - c)) << endl;;
//	system("pause");
//	return 0;
//}