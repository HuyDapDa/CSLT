//#include <iostream>
//using namespace std;
//int main()
//{
//	double dai, rong;
//	cout << "Nhap do dai, do rong: ";
//	cin >> dai >> rong;
//	cout << "Dien tich hinh chu nhat: " << dai * rong << endl;
//	system("pause");
//	return 0;
//}