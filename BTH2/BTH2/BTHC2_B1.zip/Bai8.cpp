//#include <iostream>
//#include <cmath>
//using namespace std;
//int main()
//{
//	double n;
//	cout << "Gia mua cua mot mat hang: ";
//	cin >> n;
//	cout << "Gia ban cua mat hang: " << n + n * 0.6 << endl;
//	system("pause");
//	return 0;
//}