//#include<iostream>
//using namespace std;
//int main()
//{
//	int tongsosach, vanchuyen;
//	double tongtiensach, thue;
//	cout << "Nhap tong tien sach: ";
//	cin >> tongtiensach;
//	cout << "Nhap tong so sach: ";
//	cin >> tongsosach;
//	vanchuyen = 2000 * tongsosach;
//	thue = tongtiensach * 0.075;
//	
//	cout << "Tong gia tri don hang: " << tongtiensach + thue + vanchuyen << endl;
//	system("pause");
//	return 0;
//}