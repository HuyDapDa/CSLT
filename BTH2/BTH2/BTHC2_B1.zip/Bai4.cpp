//#include <iostream>
//#include <cmath>
//using namespace std;
//double pi = 3.141593;
//int main()
//{
//	double r;
//	cout << "Nhap ban kinh hinh tron: ";
//	cin >> r;
//	cout << "Chu vi hinh tron: " << 2 * pi * r << endl;
//	cout << "Dien tich hinh tron: " << pow(r,2) * pi << endl;
//	system("pause");
//	return 0;
//}