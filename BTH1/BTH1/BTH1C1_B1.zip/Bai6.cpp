//#include <iostream>
//#include <string>
//using namespace std;
//int main()
//{
//	string ten;
//	cout << "Xin chao, ten toi la Hoa " << endl;
//	cout << "Ten ban la gi? " << endl;
//	cin >> ten;
//	cout << "Chao ban, " << ten << endl;
//	system("pause");
//	return 0;
//}