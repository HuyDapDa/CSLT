//#include <iostream>
//using namespace std;
//int main() 
//{
//	cout << "*********        ***       *        * " << endl;
//	cout << "*       *       *   *     ***      * *" << endl;
//	cout << "*       *      *     *   *****    *   *" << endl;
//	cout << "*       *      *     *     *     *     *" << endl;
//	cout << "*       *      *     *     *    *       *" << endl;
//	cout << "*       *      *     *     *     *     *" << endl;
//	cout << "*       *      *     *     *      *   *" << endl;
//	cout << "*       *       *   *      *       * *" << endl;
//	cout << "*********        ***       *        * " << endl;
//	system("pause");
//	return 0;
//
//}