//#include<iostream>
//using namespace std;
//int main()
//{
//	int n,m;
//	int tong = 0;
//	cout << "Nhap so lan nhap ";
//	cin >> n;
//	for (int i = 1; i <= n;i++)
//	{
//		cout << "Nhap so thu " << i << " : ";
//		cin >> m;
//		tong += m;
//	}
//	cout<<"Tong 3 so vua nhap la: " << tong << endl;;
//	system("pause");
//	return 0;
//}