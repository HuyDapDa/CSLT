//#include<iostream>
//using namespace std;
//int main()
//{
//	int n, m;
//	int demsochan = 0;
//	int demsole = 0;
//	int dem = 0;
//	do
//	{
//		cout << "Nhap 2 so nguyen duong: ";
//		cin >> n >> m;
//		if (n < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;
//	} while (n < 0);
//	for (int i = n;i <= m;i++)
//	{
//		if (i % 2 == 0)
//			demsochan++;
//		else
//			demsole++;
//		if (10 % i == 0)
//			dem++;
//		
//	}
//	cout << "Tu " << n << " den " << m << " co " << demsochan << " so chan va " << demsole << " so le va " 
//		<< dem << " so la uoc cua 10" <<endl;
//	return 0;
//}
