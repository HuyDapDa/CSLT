//#include <iostream>
//using namespace std;
//int main()
//{
//	int h;
//	do
//	{
//		cout << "Nhap chieu cao cua tam giac: ";
//		cin >> h;
//		if (h < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;;
//	} while(h < 0);
//	for (int i = 1; i <= h;i++)
//	{
//		for (int j = 0; j < i;j++)
//		{
//			cout << "*";
//		}
//
//		cout << endl;
//	}
//	return 0;
//}