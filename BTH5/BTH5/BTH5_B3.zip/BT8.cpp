//#include <iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int tong = 0;
//	do
//	{
//		cout << "Nhap so nguyen duong: ";
//		cin >> n;
//		if (n < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;;
//	} while (n < 0);
//	for (int i = 1; i <= n; i++)
//	{
//		if (i % 2 == 1)
//			tong += i;
//	}
//	cout <<"Tong cac so le tu 1 den "<< n << " la " << tong << endl;
//	system("pause");
//	return 0;
//		
//}