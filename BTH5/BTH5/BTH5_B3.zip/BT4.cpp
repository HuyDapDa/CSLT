//#include <iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int giaithua = 1;
//	cout << "Nhap so nguyen: ";
//	cin >> n;
//	for (int i = 1; i <= n; i++)
//	{
//		giaithua *=  i;
//	}
//	cout <<"Giai thua "<< n << " la " << giaithua << endl;
//	system("pause");
//	return 0;
//		
//}