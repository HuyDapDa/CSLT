//#include <iostream>
//using namespace std;
//int main()
//{
//	int d, r;
//	do
//	{
//		cout << "Nhap chieu dai, chieu rong: ";
//		cin >> d >> r;
//		if (d < 0 || r < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;;
//	} while(d < 0 || r < 0);
//	for (int i = 0; i < d;i++)
//	{
//		for (int j = 0; j < r;j++)
//		{
//			cout << "*";
//		}
//		cout << endl;;
//	}
//	return 0;
//}