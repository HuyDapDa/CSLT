//#include <iostream>
//#include <cmath>
//using namespace std;
//int main()
//{
//	int n,s1=0;
//	double s2=0, s3=0;
//	do
//	{
//		cout << "Nhap so nguyen duong: ";
//		cin >> n;
//		if (n < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;;
//	} while (n<0);
//	
//	for (double i = 1; i <= n;i++)
//	{
//		s1 = s1 + pow(i, 2);
//		s2 = s2 + (1 / i);
//		s3 = s3 + (1 / (2*i-1));
//	}
//	cout<<"S1 = " << s1 << endl;
//	cout<<"S2 = " << s2 << endl;
//	cout<<"S3 = " << s3 << endl;
//	system("pause");
//	return 0;
//}