//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	do
//	{
//		cout << "Nhap so nguyen duong: ";
//		cin >> n;
//		if (n < 0)
//			cout << "Nhap sai, nhap lai!!!" << endl;;
//	} while (n < 0);
//	for (int i = 1; i <= 10;i++)
//	{
//		cout<< n << "*"<< i << " = " << n * i << endl;
//	}
//	
//	return 0;
//}